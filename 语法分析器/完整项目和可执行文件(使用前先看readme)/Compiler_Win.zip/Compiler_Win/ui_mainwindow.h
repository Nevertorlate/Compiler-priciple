#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QObject>
#include <QMainWindow>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>
#include <QTextEdit>
#include <QSplitter>
#include <QTableWidget>
QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionOpen;
    QAction *actionSave;
    QAction *actionTextEdit;
    QAction *actionSyntax_Analysis;
    QAction *actionSyntax_Analysis_Window;
    QTextEdit *textEdit;
    QTableWidget *table;
    QTableWidget *table_first;
    QTableWidget *table_follow;
    QWidget *centralwidget;
    QMenuBar *menubar;
    QMenu *menu;
    QMenu *menuWindow;
    QMenu *menuAnalyze;
    QStatusBar *statusbar;
    QDockWidget *TextEdit;
    QWidget *dockWidgetContents;
    QWidget *dockWidgetContents_4;
    QDockWidget *SyntaxAnalysisWin;
    QWidget *dockWidgetContents_5;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(800, 600);

        actionOpen = new QAction(QIcon(":/resource/Open.ico"), QObject::tr("&Open..."), MainWindow);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        actionOpen->setShortcuts(QKeySequence::Open);
        actionOpen->setStatusTip(QObject::tr("Open an existing file"));
        actionSave = new QAction(QIcon(":/resource/save.ico"), QObject::tr("&Save..."), MainWindow);
        actionSave->setShortcuts(QKeySequence::Save);
        actionSave->setStatusTip(QObject::tr("Save a new file"));
        actionSave->setObjectName(QStringLiteral("actionSave"));

        actionTextEdit = new QAction(MainWindow);
        actionTextEdit->setObjectName(QStringLiteral("actionTextEdit"));
        actionSyntax_Analysis = new QAction(MainWindow);
        actionSyntax_Analysis->setObjectName(QStringLiteral("actionSyntax_Analysis"));
        actionSyntax_Analysis_Window = new QAction(MainWindow);
        actionSyntax_Analysis_Window->setObjectName(QStringLiteral("actionSyntax_Analysis_Window"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 23));
        menu = new QMenu(menubar);
        menu->setObjectName(QStringLiteral("menu"));
        menuWindow = new QMenu(menubar);
        menuWindow->setObjectName(QStringLiteral("menuWindow"));
        menuAnalyze = new QMenu(menubar);
        menuAnalyze->setObjectName(QStringLiteral("menuAnalyze"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);
        TextEdit = new QDockWidget(MainWindow);
        TextEdit->setObjectName(QStringLiteral("TextEdit"));
        TextEdit->setAutoFillBackground(false);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QStringLiteral("dockWidgetContents"));
        TextEdit->setWidget(dockWidgetContents);
        MainWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(1), TextEdit);
        dockWidgetContents_4 = new QWidget();
        dockWidgetContents_4->setObjectName(QStringLiteral("dockWidgetContents_4"));
        SyntaxAnalysisWin = new QDockWidget(MainWindow);
        SyntaxAnalysisWin->setObjectName(QStringLiteral("SyntaxAnalysisWin"));
        dockWidgetContents_5 = new QWidget();
        dockWidgetContents_5->setObjectName(QStringLiteral("dockWidgetContents_5"));
        SyntaxAnalysisWin->setWidget(dockWidgetContents_5);

        MainWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(2), SyntaxAnalysisWin);

        menubar->addAction(menu->menuAction());
        menubar->addAction(menuAnalyze->menuAction());
        menubar->addAction(menuWindow->menuAction());
        menu->addAction(actionOpen);
        menu->addAction(actionSave);
        menuWindow->addAction(actionTextEdit);
        menuWindow->addAction(actionSyntax_Analysis_Window);
        menuAnalyze->addAction(actionSyntax_Analysis);

        textEdit = new QTextEdit(TextEdit);
        TextEdit->setWidget(textEdit);
        TextEdit->setWidget(textEdit);
        QFont font;
        font.setPointSize(14);
        TextEdit->setFont(font);
        retranslateUi(MainWindow);
        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        actionOpen->setText(QApplication::translate("MainWindow", "打开文件", Q_NULLPTR));
        //actionOpen_grammar->setText(QApplication::translate("MainWindow", "选择文法文件", Q_NULLPTR));
        actionSave->setText(QApplication::translate("MainWindow", "保存文件", Q_NULLPTR));
        actionTextEdit->setText(QApplication::translate("MainWindow", "编辑窗口", Q_NULLPTR));
        actionSyntax_Analysis->setText(QApplication::translate("MainWindow", "语法分析", Q_NULLPTR));
        actionSyntax_Analysis_Window->setText(QApplication::translate("MainWindow", "语法分析窗口", Q_NULLPTR));
        menu->setTitle(QApplication::translate("MainWindow", "打开", Q_NULLPTR));
        menuWindow->setTitle(QApplication::translate("MainWindow", "窗口", Q_NULLPTR));
        menuAnalyze->setTitle(QApplication::translate("MainWindow", "分析", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
